export default {
    plugins: {
        autoprefixer: {},
    },
}
